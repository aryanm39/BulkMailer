// import React, { StrictMode } from 'react'
// import { createRoot } from 'react-dom/client'
// import './index.css'
// import App from './App.jsx'
// import { Provider } from 'react-redux';
// import store from './redux/store.jsx'

// createRoot(document.getElementById('root')).render(
//   <StrictMode>
//    <Provider store={store}>
//     <App />
//     </Provider>
//   </StrictMode>,
// )

// Redux ToolKit
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import { Provider } from 'react-redux'
import { store } from "./store";
createRoot(document.getElementById('root')).render(
  <Provider store={store}>
    <App />
  </Provider>,
)
