import { configureStore, createSlice } from "@reduxjs/toolkit";

//  Create slice (state + reducers)
const counterSlice = createSlice({
  name: "counter",
  initialState: { value: 0 },
  reducers: {
    increment: (state) => { state.value += 1 },
    decrement: (state) => { state.value -= 1 },
  },
});

//  Export actions
export const { increment, decrement } = counterSlice.actions;

//  Create store and attach slice reducer
export const store = configureStore({
  reducer: counterSlice.reducer,
});
