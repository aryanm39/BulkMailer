// import React from "react";
// import { useSelector,useDispatch } from 'react-redux';
// import { Increment,Decrement } from "./redux/counterActions.jsx";
// import './App.css'

// function App () 
// {
//   const count = useSelector((state) => state.counter);
//   const dispatch = useDispatch();

//   return(
//     <div>
//       <h1> React Redux </h1>
//       <h2>Current Count: {count} </h2>
//       <button onClick={()=>dispatch(Increment())}>Increment</button>
//       <button onClick={()=>dispatch(Decrement())}>Decrement</button>
//       <p>Counter Example (Increment & decrement) by dispatching action from reducer</p>
//     </div>
//   );
// }
// export default App;




// Redux ToolKit
import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { store, increment, decrement } from "./store";
// Redux Toolkit = modern, clean, and recommended way
export default function App() {
  const count = useSelector((state) => state.value); // read value from store
  const dispatch = useDispatch();

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Counter App</h1>
      <h2>Count: {count}</h2>
      <button 
        onClick={() => dispatch(increment())} 
        style={{ marginRight: "10px" }}
      >
        +
      </button>
      <button onClick={() => dispatch(decrement())}>-</button>
    </div>
  );
}
