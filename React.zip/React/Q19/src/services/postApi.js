import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// API Slice
export const postsApi = createApi({
  reducerPath: "postsApi", // unique name for store
  baseQuery: fetchBaseQuery({ baseUrl: "https://jsonplaceholder.typicode.com" }),
  endpoints: (builder) => ({
    getPosts: builder.query({
      query: () => "/posts", // endpoint
    }),
  }),
});

// Export auto-generated hook
export const { useGetPostsQuery } = postsApi;
