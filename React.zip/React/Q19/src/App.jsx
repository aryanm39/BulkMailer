import React from "react";
import { useGetPostsQuery } from "./services/postApi";

export default function App() {
  const { data, error, isLoading } = useGetPostsQuery();

  if (isLoading) return <p>Loading posts...</p>;
  if (error) return <p>Something went wrong </p>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>Posts from API</h2>
      <ul>
        {data.map((post) => (
          <li key={post.id}>
            <b>{post.title}</b>
            <img src={post.url} alt="img" />
            <p>{post.body}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
