import './App.css'
import ItemList from './components/ItemList'
import Cart from './components/Cart'

function App() {
  return (
    <>
    <ItemList />
    <Cart />
    </>
  )
}
export default App
