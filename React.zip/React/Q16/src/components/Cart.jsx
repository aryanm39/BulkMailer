import CartItem from "./CartItem";
import { useSelector } from "react-redux";
export default function Cart()
{
    
    const items = useSelector(state => state.cartItems)
    return <div
            style={{
                position: 'fixed',
                top: '0',
                right: '0',
                width: '33.3333%',
                height: '100vh',
                backgroundColor : '#161d32ff',
                overflowY: 'auto',
                zIndex: '1000',
                border : '2px solid gray'
            }}>
            <h3>Cart</h3>
            <br />
            <br />
            {items.length == 0 ? 
            <h4>cart is empty</h4> : 
            items.map(item => <CartItem key={item.id} id={item.id} name={item.name} quantity={item.quantity}/>)}
    </div>
}