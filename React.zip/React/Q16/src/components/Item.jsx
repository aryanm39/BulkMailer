import { useDispatch, useSelector } from "react-redux"
import { add } from "../store/CartAction"

export default function Item({id, name}) {
    const item = {
        id,
        name,
        quantity : 0
    }
    
    const dispatch = useDispatch()
    const handleAdd = ()=>{
        dispatch(add(item))
    }
    return <div
    style={{
        border : "2px solid gray",
        width : "16vw",
        height : "12vh",
        float : 'left',
        margin : '15px'
    }}>
        <h5>{name}</h5>
        <button onClick={handleAdd}>add</button>
    </div>
}