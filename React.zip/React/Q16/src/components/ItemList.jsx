import Item from "./Item";

export default function ItemList()
{
    const items = [{
        id : 1,
        name : 'item 1'
    },
    {
        id : 2,
        name : 'item 2'
    },
    {
        id : 3,
        name : 'item 3'
    },
    {
        id : 4,
        name : 'item 4'
    },
    {
        id : 5,
        name : 'item 5'
    },
    {
        id : 6,
        name : 'item 6'
    }
    ]
    return <div
            style={{
                position: 'fixed',
                top: '0',
                left: '0',
                width: '66.6666%',
                height: '100vh',
                backgroundColor : '#161d32ff',
                overflowY: 'auto',
                zIndex: '1000',
                border : '2px solid gray'
            }}
           >
            <h3>Items</h3>
            <br />
            <br />
            <br />
            {items.map(item => <Item key={item.id} id={item.id} name={item.name}/>)}
    </div>
}