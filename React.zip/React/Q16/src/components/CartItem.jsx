import { useDispatch } from "react-redux"
import { remove } from "../store/CartAction";

export default function CartItem({id, name, quantity}) {

    const dispatch = useDispatch();

    const handleRemove = () => {
        dispatch(remove(id))    
    }

    return <div
    style={{
        border : '2px solid gray',
        width : '80%',
        height : '8vh',
        margin : '10px auto',
    }}>
        <div
        style={{
            width : '50%',
            float : "left",
            border : '1px',
            height : '100%'
        }}>
            <h4 style={{textAlign : 'left', marginTop : '10px', marginLeft : '10px'}}>{name}</h4>
            <h5 style={{textAlign : 'left', marginTop: '-20px',marginLeft : '10px'}}>quantity : {quantity}</h5>
        </div> 
        <div>
            <button style={{marginTop : '15px'}}
            onClick={handleRemove}>remove</button>
        </div>
    </div>
}