const initialState = {
    cartItems : []
}

export default function cartReducer(state = initialState, action) {
    switch(action.type) {
        case 'ADD' : 
        const existingItem = state.cartItems.find(item => item.id == action.payload.id)
        if(existingItem) {
            return {
                ...state,
                cartItems : state.cartItems.map(item => item.id === action.payload.id ? {... item, quantity : item.quantity + 1} : item)
            }
        }
        else
            return {
                ...state,
                cartItems : [...state.cartItems, {...action.payload, quantity : 1}]
            }
        case 'REMOVE' :

            const itemToRemove = state.cartItems.find(item => item.id === action.payload);
            if(!itemToRemove) {
                return state
            }

            if(itemToRemove.quantity > 1)
            {
                return {
                    ...state,
                    cartItems : state.cartItems.map(item => item.id === action.payload ? {...item, quantity : item.quantity - 1 } : item)
                }
            }
            else {
                return {
                    ...state,
                    cartItems : state.cartItems.filter(item => item.id !== action.payload)
                }
            }

        default :
            return state;
    }

}
