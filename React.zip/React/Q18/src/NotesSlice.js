import { createSlice, nanoid } from '@reduxjs/toolkit';

const notesSlice = createSlice({
  name: 'notes',
  initialState: [],
  reducers: {
    addNote: {
      reducer(state, action) {
        state.push(action.payload);
      },
      prepare(text) {
        return {
          payload: {
            id: nanoid(),
            text,
          }
        };
      }
    },
    deleteNote(state, action) {
      return state.filter(note => note.id !== action.payload);
    }
  },
});

export const { addNote, deleteNote } = notesSlice.actions;
export default notesSlice.reducer;
