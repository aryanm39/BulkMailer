import NoteApp from './NotesApp';

const App = () => {
  return (
    <div>
      <NoteApp />
    </div>
  );
};

export default App;
