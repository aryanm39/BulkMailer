import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addNote, deleteNote } from './NotesSlice';

const NoteApp = () => {
  const [noteText, setNoteText] = useState('');
  const notes = useSelector(state => state.notes);
  const dispatch = useDispatch();

  const handleAddNote = () => {
    if (noteText.trim()) {
      dispatch(addNote(noteText));
      setNoteText('');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Notes App</h2>
      <input
        value={noteText}
        onChange={(e) => setNoteText(e.target.value)}
        placeholder="Type a note..."
      />
      <button onClick={handleAddNote}>Add Note</button>

      <ul>
        {notes.map(note => (
          <li key={note.id}>
            {note.text}
            <button onClick={() => dispatch(deleteNote(note.id))}>
              del
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NoteApp;
