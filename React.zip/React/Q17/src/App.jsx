import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate  } from 'react-router-dom';
import './App.css'
function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const navigate = useNavigate()

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/login', {
        username,
        password
      });
      const tokenFromBackend = response.data.token

      alert('Login successful!');


      try {
      const res = await axios.get('http://localhost:5000/protected', {
        headers: {
          Authorization: `Bearer ${tokenFromBackend}`
        }
      });
      navigate('/dashboard')
    } catch (err) {
      alert('Access denied');
    }

    } catch (err) {
      alert('Login failed');
    }
  };

  const getProtected = async () => {
    
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} /><br /><br />
        <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} /><br /><br />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default App;
