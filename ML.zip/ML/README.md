### Step 1:  Load the data
### Step 2:  Preprocess the data -> Missing Values/Null values, Categorial to Numeric, 
### Step 3:  Define Features and Target -> X & y
### Step 4:  Train Test Split
### Step 5:  Train the Model
### Step 6:  Predict the Test Data
### Step 7:  Evalute the Model: MAE,MSE,r2 SCORE(Accuracy)